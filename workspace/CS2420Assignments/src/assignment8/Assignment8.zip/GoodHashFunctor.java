package assignment8;

public class GoodHashFunctor implements HashFunctor {

	public int hash(String item) {

		String total = "" + 1;
		char[] x = item.toCharArray();
		for (int i = 0; i < x.length && total.length() < 15; i++) {
			int y = x[i];
			total = total + y;
		}
//		if (total == "") {
//
//			int totel = 0;
//			char[] a = item.toCharArray();
//			for (int i = 0; i < a.length; i++) {
//				int b = a[i];
//				totel = totel + b;
//
//			}
//			return totel;
//		}
		return (int) Math.abs(Long.parseLong(total));
	}

}
